To install this extension please follow the steps below.

------------

1. Open Photoshop

2. In Photoshop navigate to File / Scripts / Browse

3. Navigate to the Ext-Installer.jsx file and click open

------------

Photoshop will now walk you through the installation process. 
After installation you will be required to restart Photoshop.