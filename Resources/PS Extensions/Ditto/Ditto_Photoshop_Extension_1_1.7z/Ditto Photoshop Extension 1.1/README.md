Thank you for downloading Ditto! I hope it saves you a bunch of time. 

# How to install / upgrade

Ditto currently requires Photoshop CC 2015 or newer.

If you have that then open it up and go to File → Scripts → Browse... and select the installer.jsx file in the same folder as these instructions. The rest is handled automatically.

# How Ditto works

When you first create a variable in a document, you’ll see that a folder called “dittoVariables” is added to your layers panel. This is simply where Ditto stores all of the information about your document’s variables. Doing so means that you can pass a file off to a co-worker / client / et cetera and not have to worry about syncing a separate variables file or 3rd party service. It’s all self-contained in your PSD.

# License

The Ditto Photoshop extension is the copyright of Elliot Jackson ©2015.

---

## Manual install / upgrade

Using the script and instructions provided above is the easiest way to install Ditto. If for some reason the install is failing however, then you can follow these instructions to install it manually.

1. Open the “ASSETS” folder contained within this folder and rename the “HTML” folder to “com.casualnotebook.variables”.

2. Copy the “com.casualnotebook.variables” folder.

3. Paste it in one of the following locations based on your system (and select “Replace” when pasting if you already have a folder with the same name in there):

**Mac:** `~/Library/Application Support/Adobe/CEP/extensions/`

**Win 32bit:** `C:\Program Files\Common Files\Adobe\CEP\extensions\`

**Win 64bit:** `C:\Program Files (x86)\Common Files\Adobe\CEP\extensions\`

4. Restart Photoshop.