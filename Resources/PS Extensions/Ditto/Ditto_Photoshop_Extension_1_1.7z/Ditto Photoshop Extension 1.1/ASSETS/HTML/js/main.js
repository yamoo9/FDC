(function ()
{

  //
  // Setup
  //

  'use strict';
  var csInterface = new CSInterface();
  var currentVersion = "1.1";
  var gExtensionId = "com.casualnotebook.variables";

  //
  // Utility: Load JSX file
  //

  function loadJSX(fileName)
  {
    var extensionRoot = csInterface.getSystemPath(SystemPath.EXTENSION) + "/jsx/";
    csInterface.evalScript('$.evalFile("' + extensionRoot + fileName + '")');
  }

  //
  // Utility: Make persistent
  //

  function Persistent(inOn)
  {
    if (inOn)
    {
      var event = new CSEvent("com.adobe.PhotoshopPersistent", "APPLICATION");
    } else {
      var event = new CSEvent("com.adobe.PhotoshopUnPersistent", "APPLICATION");
    }
    event.extensionId = gExtensionId;
    csInterface.dispatchEvent(event);
  }
  Persistent(true);

  //
  // Delete variable
  //

  function deleteButton ()
  {
    $("#content").on("click", ".deleteButton", function ()
    {
      var typeSelection = $(this).parent().find(".variableSelect").val();
      var variableName  = "#" + $(this).parent().find(".variableName input").val();
      var variableValue = $(this).parent().find(".variableValue input").val();

      var obj = {
        kind: typeSelection,
        key: variableName,
        value: variableValue
      }

      csInterface.evalScript( 'removeVariable(' + JSON.stringify(obj) + ')' );

      $(this).closest(".singleVariable").remove();
    });
  }

  //
  // Initialise
  //

  function init()
  {
    themeManager.init();
    loadJSX("json2.js");

    $('select').select2({
      minimumResultsForSearch: Infinity
    });

    variables();

    var buster = Math.random().toString(36).substring(7);
    $.get("http://elliotekj.com/photoshop/ditto/version.txt?"+buster, currentVersionCheck);
  }
  init();
  deleteButton();

  //
  // Variable updater: single
  //

  function variables()
  {
    $("#content").on("click", ".variableUpdate", function ()
    {
      var typeSelection = $(this).parent().find(".variableSelect").val();
      var variableName  = "#" + $(this).parent().find(".variableName input").val();
      var variableValue = $(this).parent().find(".variableValue input").val();

      var obj = {
        kind: typeSelection,
        key: variableName,
        value: variableValue
      }

      csInterface.evalScript( 'variableUpdater(' + JSON.stringify(obj) + ')' );
    });
  }

  //
  // Variable updater: all
  //

  function variablesAll()
  {
    $('.variableTable').children('.singleVariable').each(function ()
    {
      var typeSelection = $(this).find(".variableSelect").val();
      var variableName  = "#" + $(this).find(".variableName input").val();
      var variableValue = $(this).find(".variableValue input").val();

      var obj = {
        kind: typeSelection,
        key: variableName,
        value: variableValue
      }

      csInterface.evalScript( 'variableUpdater(' + JSON.stringify(obj) + ')' );
    });
  }

  $("#content").on("click", ".refreshAllVars", function ()
  {
    variablesAll();
  });

  //
  // Variable fetcher
  //

  $(".refresh-doc").click(function ()
  {
    csInterface.evalScript( 'retrieveMeta()' );
    csInterface.evalScript( 'getAllHTML(allHTML)', function(result)
    {
      $(".variableTable").empty();

      $(".variableTable").append(result);
      init();

      $("select option").each(function()
      {
        $(this).siblings("[value="+ this.value+"]").remove();
      });

      deleteButton();
    });
  });

  //
  // Add variable
  //

  $("#content").on("click", ".addVariable", function ()
  {
    var singleVariable = "<div class='singleVariable injected'><button class='deleteButton kecleon-button'><svg xmlns='http://www.w3.org/2000/svg' preserveAspectRatio='xMidYMid' width='16' height='2' viewBox='0 0 16 2'><path class='cls-1' d='M0 0h16v2H0z'/></svg></button> <div class='variableType'> <select class='variableSelect kecleon-select'> <option value='fill'>Fill</option> <option value='text'>Text</option> <option value='visibility'>Visibility</option> <option value='fontSize'>Font Size</option> <option value='fontFamily'>Font Family</option> <option value='fontColour'>Font Colour</option> <option value='lineHeight'>Line Height</option> <option value='positionX'>X</option> <option value='positionY'>Y</option> </select> </div><div class='variableName'> <input type='text' name='variableName' class='kecleon-text-input hostFontSize' placeholder='Variable name'> </div><div class='variableValue'> <input type='text' name='variableValue' class='kecleon-text-input hostFontSize' placeholder='Variable value'> </div><button class='variableUpdate kecleon-button'><svg xmlns='http://www.w3.org/2000/svg' preserveAspectRatio='xMidYMid' width='14' height='16' viewBox='0 0 14 16'><path d='M7 16c-3.866 0-7-3.134-7-7s3.134-7 7-7V0l4 3-4 3V4C4.24 4 2 6.24 2 9s2.24 5 5 5c2.72 0 4.922-2.175 4.988-4.88l1.88-1.462C13.953 8.093 14 8.54 14 9c0 3.866-3.134 7-7 7z' class='cls-1'/></svg></button></div>";

    $('.variableTable').append(singleVariable);
    singleVariable = "";

    $('.variableTable .injected:last-child select').select2({
      minimumResultsForSearch: Infinity
    });
  });

  //
  // Clear list
  //

  var clearListTriggered = "false";

  $(".clearList").click(function ()
  {
    $(".variableTable").empty();
  });

  //
  // Update notification
  //

  function currentVersionCheck(data)
  {
    if (currentVersion < data)
    {
      $(".updateAvailable").show();
    }
  }

}());