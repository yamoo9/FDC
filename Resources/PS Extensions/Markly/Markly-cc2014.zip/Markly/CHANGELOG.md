# Markly Change Log


### 21 January, 2015

- Now you can add overlay to any layer or group! You can change settings of overlay color & opacity in sidebar.
- Fixed the incorrect label position when the distance between two layers is too small.


### 19 January, 2015

- Added realtime spec data saving! Now each time you updated your measurements in Markly, the data will be saved into the metadata of your file. Be sure to save your PSD before existing PS.
- Added font size adjustments. You can move the slider to change the font size used in measurements. The current range is from 10px to 30px.
- Added shortcut! Now press Alt when clicking a measurement, and this measurement will be deleted.
- Enable users to toggle the visibility of element. Now you can select small elements behind another large one.
- Added the 'Check for updates automatically' option.
- Added the 'Import active document automatically when launching Markly' option.

- Fixed the bug that elements have the incorrect position when the background layer opacity is enabled.
- Fixed the vector shape border width & radius display in sidebar.

- Tweaked the update notification toolbar.


### 16 January, 2015

- Added fix for importing large amount of hidden layers.


### 15 January, 2015

- Fully compatible with Retina screens.
- Fixed the coordinate position issue.
- Will prompt you to upgrade PS if Markly found it cannot be installed.
- Tweaked window UI.


### 14 January, 2015

- Initial Launch! :)
