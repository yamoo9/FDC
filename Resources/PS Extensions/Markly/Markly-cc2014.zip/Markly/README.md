# Markly

**Markly** is a spec'ing app for web & mobile designers.It make it a fun to create specs within Adobe Photoshop & Sketch.

# System Requirements

* Photoshop version - Requires Photoshop CC 2014 2.0.0 Release and later, Mac & Windows.
* Sketch version - Requires Sketch 3.0+


# How to Install

For Photoshop CC 2014 version, please find the .zxp file in your downloaded package, and double click it launch Adobe Extension Manager. Then follow the instructions to complete the installation.

For Sketch version, we will provide the details once it's released.

# Support Policy

We take great pride in our software here. And we are happy to assist you with any adobe extensions or plugins related question. The Lifetime Support Policy below describes what support you can expect from us.

If you have any questions about this Support Policy or do not agree with it, please do not hesitate to contact us. We may amend this Support Policy from time to time, so you should check this page from time to time to ensure that you are aware of any changes that have been made. This Support Policy is effective from 01 January 2015.

## What Our Support Service Covers

We only support our Products. Our Support Service includes assistance with Product installations, configuration and use.

## What Our Support Service Doesn’t Cover
Our Support Service does not cover our Products supplied by 3rd Parties who are not our Resellers. We do not give general Adobe Products & Sketch support. Contact their producers for assistance.

## Hours of Operation
Our general support hours are Monday to Friday, 07:30-12:30 (GMT +8). During this time, we strive to answer all support request within 24 hours. If the request is more advanced or technical in nature the response time may vary.

## Product Support Channels
We will only provide support via ** e-mail. We don’t provide our support service through other channels (including, but not limited to Twitter, Facebook or any other method) at this moment.

After purchasing Markly, simply include your purchase information (Purchaser Name, Purchase Date and your license code) in the support request e-mail.

## Third-Party Plugins
Due to the huge amount of third-party plugins that exist inside the Adobe marketplace, we can not offer our support service for any issue involving a third-party plugin.

## Bug Fixing
We will fix any bug within any of our software as quickly as possible after they are brought to our attention. If you find a bug within our software please contact our support on this page and we will try to provide a solution.


## Contact Us
Website [http://marklyapp.com](http://marklyapp.com)
Email [team@marklyapp.com](mailto:team@marklyapp.com)
Twitter [@marklyapp](https://twitter.com/marklyapp)
