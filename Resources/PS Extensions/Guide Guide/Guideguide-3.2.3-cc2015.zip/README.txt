Adobe removed the Extension Manager in CC 2015, so manual install is currently required.

1. Download the zip file above and unzip it (you already did that part!).

   OSX

     Launch and run this command to open the install folder:
     open /Library/Application\ Support/Adobe/CEP/extensions/

     Copy the unzipped “GuideGuide” folder into the extensions folder.

   Windows

     Copy the unzipped GuideGuide folder to the appropriate directory.
     Windows 64: C:\Program Files (x86)\Common Files\Adobe\CEP\extensions\
     Windows 32: C:\Program Files\Common Files\Adobe\CEP\extensions\

     If the Adobe\CEP\extensions folder does not exist, you can create it.

2. Restart Photoshop. You’ll find GuideGuide at Window > Extensions > GuideGuide

   Ensure that you do not modify the GuideGuide folder. Doing so will cause a
   “The GuideGuide extension could not be loaded because it was not properly
   signed” error when you try to launch it.
