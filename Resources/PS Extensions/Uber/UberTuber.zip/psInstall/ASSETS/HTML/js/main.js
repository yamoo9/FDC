/*jslint vars: true, plusplus: true, devel: true, nomen: true, regexp: true, indent: 4, maxerr: 50 */
/*global $, window, document, location, CSInterface, SystemPath, themeManager*/


$(document).ready(function () {
    var csi = new CSInterface(),
        extpath = decodeURI(CSInterface.prototype.getSystemPath(SystemPath.EXTENSION)),
        searchField = $('.ps_field'),
        searchBtn = $('.ps_btn'),
        video_url = '',
        video_id = '',
        ampersandPosition = '',
        correct_size = false,
        video_preview_url_1 = '',
        video_preview_url_2 = '',
        video_preview_url_3 = '',
        pathToFile = '',
        video_title = '',
        reg = /^\d+$/,
        player = 'youtube';


    // ================
    // Extesion UI
    // ================
    searchField.keyup(function (event) {
        if (event.keyCode == 13) {
            searchBtn.click();
        }
    });
    
    $(document).on('click', '.ps_btn', function (e) {
        try {
            video_url = searchField.val();

            if (reg.test(video_url) == true || video_url.match('vimeo') != null) {
                player = 'vimeo';
                video_id = video_url;

                if (video_url.match('eo.com') != null) {
                    video_id = video_url.split('com/')[1];
                }

                ampersandPosition = video_id.indexOf('?');
                if (ampersandPosition != -1) {
                    video_id = video_id.substring(0, ampersandPosition);
                }

                pathToFile = createTempFolder() + video_id + '.jpg';

                getVimeoInfo(video_id);

            } else {
                player = 'youtube';
                video_id = video_url;

                if (video_url.match('youtube') != null) {
                    video_id = video_url.split('v=')[1];
                }

                if (video_url.match('youtu.be') != null) {
                    video_id = video_url.split('.be/')[1];
                }

                ampersandPosition = video_id.indexOf('&');
                if (ampersandPosition != -1) {
                    video_id = video_id.substring(0, ampersandPosition);
                }

                video_preview_url_1 = "http://img.youtube.com/vi/" + video_id + "/maxresdefault.jpg";
                video_preview_url_2 = "http://img.youtube.com/vi/" + video_id + "/sddefault.jpg";
                video_preview_url_3 = "http://img.youtube.com/vi/" + video_id + "/0.jpg";

                pathToFile = createTempFolder() + video_id + '.jpg';

                getYoutubeInfo(video_id);
            }

        } catch (e) {}

    });

    function getVimeoInfo(video_id) {
        $.ajax({
            url: 'https://vimeo.com/api/oembed.json?url=https%3A//vimeo.com/' + video_id,
            dataType: 'json',
            type: 'GET',
            success: function (data) {
                video_title = data['title'];
                video_preview_url_1 = data['thumbnail_url'];
                video_preview_url_2 = data['thumbnail_url'];
                video_preview_url_3 = data['thumbnail_url'];
                csi.evalScript('fileExist("' + pathToFile + '")', function (result) {
                    if (video_title != '') {
                        if (result == 'false') {
                            downloadFile(video_preview_url_1, video_preview_url_2, video_preview_url_3, pathToFile);
                        } else {
                            openFile(pathToFile);
                        }
                    }
                });
            },
            error: function (e) {
                //                console.log('Error: ' + e);
                video_title = 'Vimeo';
                pathToFile = extpath + '/assets/vimeo_placeholder.jpg';
                openFile(pathToFile);
            }
        });
    }

    function getYoutubeInfo(video_id) {
        $.ajax({
            url: 'http://www.youtube.com/oembed?url=http://www.youtube.com/watch?v=' + video_id + '&format=json',
            dataType: 'json',
            type: 'GET',
            success: function (data) {
                video_title = data['title'];
                csi.evalScript('fileExist("' + pathToFile + '")', function (result) {
                    if (video_title != '') {
                        if (result == 'false') {
                            downloadFile(video_preview_url_1, video_preview_url_2, video_preview_url_3, pathToFile);
                        } else {
                            openFile(pathToFile);
                        }
                    }
                });
            },
            error: function () {
                video_title = 'YouTube';
                csi.evalScript('fileExist("' + pathToFile + '")', function (result) {
                    if (video_title != '') {
                        if (result == 'false') {
                            downloadFile(video_preview_url_1, video_preview_url_2, video_preview_url_3, pathToFile);
                        } else {
                            openFile(pathToFile);
                        }
                    }
                });
            }
        });
    }



    // ================
    // Convert to Base64
    // ================
    function convertImgToBase64(url, callback, outputFormat) {
        try {
            var img = new Image();
            img.crossOrigin = 'Anonymous';
            img.onload = function () {
                if (this.width != 120) {
                    correct_size = true;
                } else {
                    correct_size = false;
                }
                var canvas = document.createElement('CANVAS');
                var ctx = canvas.getContext('2d');
                canvas.height = this.height;
                canvas.width = this.width;
                ctx.drawImage(this, 0, 0);
                var dataURL = canvas.toDataURL(outputFormat || 'image/jpeg');
                callback(dataURL);
                canvas = null;
            }
            img.src = url;
        } catch (e) {
            alert(e.line + '\n' + e);
        }
    }

    // ================
    // Create Temp Folder
    // ================
    function createTempFolder() {
        var tmpFolder = '/tmp/videoplacer/'; - 1 < window.navigator.platform.toLowerCase().indexOf('win') && (tmpFolder = csi.getSystemPath(SystemPath.USER_DATA) + '/../Local/Temp/videoplacer/');
        window.cep.fs.makedir(tmpFolder);
        return tmpFolder;
    }

    // ================
    // Add new image to DOM
    // ================
    function addImg(url) {
        $('#result').append('<img class="image_preview" src=' + url + '>');
    }

    // ================
    // Download File
    // ================
    function downloadFile(link1, link2, link3, pathToFile) {
        try {
            convertImgToBase64(link1, function (base64Img) {
                if (correct_size == true) {
                    base64Img = base64Img.substr(22); // Fix image preview
                    window.cep.fs.writeFile(pathToFile, base64Img, cep.encoding.Base64);
                    openFile(pathToFile);
                } else {
                    convertImgToBase64(link2, function (base64Img) {
                        if (correct_size == true) {
                            base64Img = base64Img.substr(22); // Fix image preview
                            window.cep.fs.writeFile(pathToFile, base64Img, cep.encoding.Base64);
                            openFile(pathToFile);
                        } else {
                            convertImgToBase64(link3, function (base64Img) {
                                base64Img = base64Img.substr(22); // Fix image preview
                                window.cep.fs.writeFile(pathToFile, base64Img, cep.encoding.Base64);
                                openFile(pathToFile);
                            });
                        }
                    });
                }
            });
        } catch (e) {
            alert(e.line + '\n' + e);
        }
    }

    // ================
    // Open File
    // ================
    function openFile(pathToFile) {
        csi.evalScript('openF("' + player + '", "' + pathToFile + '", "' + extpath + '", "' + video_title + '")');
    }

});
