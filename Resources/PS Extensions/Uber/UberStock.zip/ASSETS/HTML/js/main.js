/*jslint vars: true, plusplus: true, devel: true, nomen: true, regexp: true, indent: 4, maxerr: 50 */
/*global $, window, document, location, CSInterface, SystemPath, themeManager*/

$(document).ready(function () {
    var csi = new CSInterface(),
        offset_position = 0,
        query_limit = 25,
        searchForm = $('.plugin_search'),
        searchField = $('.ps_field'),
        withMask = document.getElementById('mask').checked,
        loading = false,
        result_count = $('.result_count'),
        searchText = '',
        shifted = '';

    $(document).keypress(function (e) {

        if (e.shiftKey) {
            console.log('Shift!');
        }

    });

    $(document).on('click', '#apply_settings', function () {
        if ($('.settings_pop').hasClass('jump2') == false) {
            $('.settings_pop').removeClass('unjump2');
            $('.settings_pop').addClass('jump2');
        } else {
            $('.settings_pop').removeClass('jump2');
            $('.settings_pop').addClass('unjump2');
        }
    });

    $(document).on('click', '#settings', function () {
        if ($('.settings_pop').hasClass('jump2') == false) {
            $('.settings_pop').removeClass('unjump2');
            $('.settings_pop').addClass('jump2');
        } else {
            $('.settings_pop').removeClass('jump2');
            $('.settings_pop').addClass('unjump2');
        }
    });

    // ================
    // Convert to Base64
    // ================
    function convertImgToBase64(url, callback, outputFormat) {
        var canvas = document.createElement('CANVAS'),
            ctx = canvas.getContext('2d'),
            img = new Image();
        img.crossOrigin = 'Anonymous';
        img.onload = function () {
            canvas.height = img.height;
            canvas.width = img.width;
            ctx.drawImage(img, 0, 0);
            var dataURL = canvas.toDataURL(outputFormat || 'image/jpeg');
            callback.call(this, dataURL);
            canvas = null;
        };
        img.src = url;
    }

    // ================
    // Create Temp Folder
    // ================
    function createTempFolder() {
        var tmpFolder = '/tmp/ubersplash/'; - 1 < window.navigator.platform.toLowerCase().indexOf('win') && (tmpFolder = csi.getSystemPath(SystemPath.USER_DATA) + '/../Local/Temp/ubersplash/');
        window.cep.fs.makedir(tmpFolder);
        return tmpFolder;
    }

    // ================
    // Add new image to DOM
    // ================
    function addImg(id, url_big, url_small, source_title, page_url) {
        var pathToFile = createTempFolder() + id + '.jpg',
            c = '',
            btnText = 'Download';
        csi.evalScript('fileExist("' + pathToFile + '")', function (result) {
            if (result === 'true') {
                c = 'img_over_down';
                btnText = 'Place';
            }
            var $boxes = $('<li class="img_item"><div class="loader"><div class="loader-inner ball-pulse"><div></div><div></div><div></div></div></div><div class="img_over ' + c + '"><span class="place_img" data-id="' + id + '" data-link_big=' + url_big + '>' + btnText + '</span><span class="sourcelink" data-sourcetitle="' + source_title + '" data-detailurl=' + page_url + '></span></div><img onload="fadeIn(this)" class="image_preview" src=' + url_small + '></li>').css('opacity', '0');
            $('.container').append($boxes);
        });
    }

    // ================
    // Extesion UI
    // ================
    searchForm.on('submit', function (e) {
        $('.img_list ul').html(' ');
        offset_position = 0;
        e.preventDefault();
        searchText = ($.trim(searchField.val())).toLowerCase();;
        loading = true;
        $('.loader2').css('display', 'block');
        $('.no-result').css('display', 'none');
        $('.end-result').css('display', 'none');
        imgLoad();
        return false;
    });

    // ================
    // Infinite Scrolling
    // ================
    $('.img_list').scroll(function () {
        if ($(this).scrollTop() >= ($('.img_list ul').height() - 1800) && loading == false) {
            loading = true;
            $('.loader2').css('display', 'block');
            $('.no-result').css('display', 'none');
            $('.end-result').css('display', 'none');
            imgLoad();
        }
    });

    // ================
    // Load photos
    // ================
    function imgLoad() {

        if (searchText == '') {

            result_count.html('');

            $.ajax({
                url: 'http://api.uberplugins.cc/api/photos/?offset=' + offset_position + '&limit=' + query_limit,
                dataType: 'json',
                success: function (data) {
                    for (var i = 0; i < data['photos'].length; i++) {
                        addImg(data['photos'][i]['id'], data['photos'][i]['original_url'], data['photos'][i]['preview_url'], data['photos'][i]['stock'], data['photos'][i]['page_url']);
                    }
                    offset_position = offset_position + query_limit;
                    loading = false;
                }
            });
        } else {
            $.ajax({
                url: 'http://api.uberplugins.cc/api/photos/?&offset=' + offset_position + '&limit=' + query_limit + '&tags=' + searchText,
                dataType: 'json',
                success: function (data) {

                    result_count.html(data['meta']['count']);

                    for (var i = 0; i < data['photos'].length; i++) {
                        addImg(data['photos'][i]['id'], data['photos'][i]['original_url'], data['photos'][i]['preview_url'], data['photos'][i]['stock'], data['photos'][i]['page_url']);
                    }

                    offset_position = offset_position + query_limit;
                    loading = false;

                    if (data['photos'].length < query_limit) {
                        $('.end-result').css('display', 'block');
                        $('.no-result').css('display', 'none');
                        $('.loader2').css('display', 'none');
                        loading = true;
                        offset_position = 0;
                    }

                    if (data['meta']['count'] == 0) {
                        $('.end-result').css('display', 'none');
                        $('.no-result').css('display', 'block');
                        $('.loader2').css('display', 'none');
                        loading = true;
                        offset_position = 0;
                    }

                }
            });
        }


    }

    // ================
    // Download File
    // ================
    function downloadFile(link, pathToFile, loader) {
        convertImgToBase64(link, function (base64Img) {
            base64Img = base64Img.substr(22); // Fix image preview
            window.cep.fs.writeFile(pathToFile, base64Img, cep.encoding.Base64);
            openFile(pathToFile, loader);
        });
    }

    // ================
    // Open File
    // ================
    function openFile(pathToFile, loader) {
        csi.evalScript('openF("' + pathToFile + '", "' + withMask + '")', function (result) {
            if (result) {
                loader.hide();
                loader.closest('li').find('.img_over').addClass('img_over_down');
                loader.closest('li').find('.place_img').html('Place');
            }
        });
    }

    // ================
    // Click to Place button
    // ================
    $(document).on('click', '.place_img', function () {
        var link = $(this).data('link_big'),
            id = $(this).data('id'),
            pathToFile = createTempFolder() + id + '.jpg';
        withMask = document.getElementById('mask').checked;
        loader = $(this).closest('li').find('.loader');
        loader.show();
        csi.evalScript('fileExist("' + pathToFile + '")', function (result) {
            if (result == 'false') {
                downloadFile(link, pathToFile, loader);
            } else {
                openFile(pathToFile, loader);
            }
        });
    });

    // ================
    // Click to Source link
    // ================
    $('body').on('click', 'span.sourcelink', function (e) {
        var detailurl = $(this).data('detailurl');
        csi.openURLInDefaultBrowser(detailurl);
    });

    window.fadeIn = function (obj) {
        $(obj).closest('li').css('opacity', '1');
    }

    imgLoad();

    var fav_tags = [
        {
            "value": "Animals"
    },
        {
            "value": "Buildings"
    },
        {
            "value": "Food"
    },
        {
            "value": "Drink"
    },
        {
            "value": "Nature"
    },
        {
            "value": "Objects"
    },
        {
            "value": "People"
    },
        {
            "value": "Technology"
    },
        {
            "value": "Transport"
    },
        {
            "value": "Apple"
    },
        {
            "value": "iMac"
    },
        {
            "value": "iPhone"
    },
        {
            "value": "Macbook"
    },
        {
            "value": "Laptop"
    },
        {
            "value": "Notebook"
    },
        {
            "value": "Unsplash"
    }
    ];

    $('#autocomplete').autocomplete({
        lookup: fav_tags
    });

});